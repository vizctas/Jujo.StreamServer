<#
.SYNOPSIS
    Elevated installer for Jujo.Stream (Vibepollo) server.
    Must be run as Administrator. Bundled inside server_bundle.zip.

.PARAMETER SourceDir
    Directory containing the extracted server bundle (same dir as this script).

.PARAMETER InstallDir
    Target installation directory. Defaults to "C:\Program Files\Vibepollo".

.PARAMETER ResultFile
    Path to write a JSON result file so the launcher can read outcome.
#>
param(
    [string]$SourceDir    = (Split-Path -Parent $PSCommandPath),
    [string]$InstallDir   = "C:\Program Files\Vibepollo",
    [string]$ResultFile   = ""
)

$ErrorActionPreference = 'Stop'

$result = [ordered]@{
    success        = $false
    message        = ""
    rebootRequired = $false
}

function Write-Result {
    if ($ResultFile) {
        $result | ConvertTo-Json | Set-Content -Path $ResultFile -Encoding UTF8 -Force
    }
}

try {
    Write-Output "Installing Vibepollo server to: $InstallDir"

    # 1. Create install directory
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

    # 2. Copy all bundle files (skip install.ps1 + any leftover result file)
    Write-Output "Copying server files..."
    Get-ChildItem -Path $SourceDir -Exclude "install.ps1","result.json" |
        ForEach-Object { Copy-Item -Path $_.FullName -Destination $InstallDir -Recurse -Force }

    # 3. Install SudoVDA virtual display driver
    $driverScript = Join-Path $InstallDir "drivers\sudovda\install.ps1"
    if (Test-Path $driverScript) {
        Write-Output "Installing SudoVDA display driver..."
        & $driverScript
        if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) {
            Write-Warning "SudoVDA install returned code $LASTEXITCODE — reboot may be required."
            $result.rebootRequired = $true
        }
    } else {
        Write-Warning "SudoVDA driver script not found, skipping."
    }

    # 4. Register ApolloService Windows service
    $svcBin = Join-Path $InstallDir "tools\sunshinesvc.exe"
    if (-not (Test-Path $svcBin)) {
        throw "Service binary not found: $svcBin"
    }

    Write-Output "Registering ApolloService..."
    # Clean up legacy service
    $null = & sc.exe delete sunshinesvc 2>$null

    $qcOut = & sc.exe qc ApolloService 2>&1
    if ($LASTEXITCODE -eq 0) {
        # Service exists — reconfigure it
        $null = & sc.exe config ApolloService binPath= "`"$svcBin`"" start= auto
    } else {
        # Create new service
        $null = & sc.exe create ApolloService `
            binPath= "`"$svcBin`"" `
            start= auto `
            DisplayName= "Apollo Stream Service"
        $null = & sc.exe description ApolloService "Jujo.Stream server — game streaming backend"
    }

    # 5. Add Windows firewall rule (best-effort)
    $fwScript = Join-Path $InstallDir "scripts\add-firewall-rule.bat"
    if (Test-Path $fwScript) {
        Write-Output "Adding firewall rule..."
        $null = & cmd.exe /c "`"$fwScript`"" 2>&1
    }

    # 6. Start the service
    Write-Output "Starting ApolloService..."
    $null = & sc.exe start ApolloService 2>&1
    # Give the process a moment to come up
    Start-Sleep -Seconds 3

    $result.success        = $true
    $result.message        = "Vibepollo server installed and started successfully."
    Write-Output "Installation complete!"

} catch {
    $result.message = "Installation failed: $($_.Exception.Message)"
    Write-Error $result.message
}

Write-Result
exit $(if ($result.success) { 0 } else { 1 })
